package com.pelican.strike

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val green = Color.rgb(57, 255, 112)
    private val bg = Color.rgb(10, 13, 12)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "PELICAN STRIKE"
            textSize = 27f
            setTextColor(green)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "BLACK  /  NEON GREEN   •   COMPANION TOOL"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val info = TextView(this).apply {
            text = "Menu flutuante com ferramentas de treino e personalização.\n\nNão lê dados do Blood Strike nem altera partidas."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val start = Button(this).apply {
            text = "ATIVAR MENU FLUTUANTE"
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Menu flutuante ativado", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "DESATIVAR MENU"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        root.addView(title)
        root.addView(sub)
        root.addView(info)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // Após conceder a permissão, o usuário toca em ATIVAR MENU FLUTUANTE.
    }
}
