package com.pelican.strike

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.max

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val neon = Color.rgb(57, 255, 112)
    private val dark = Color.rgb(12, 17, 15)
    private val channel = "pelican_overlay"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showBubble()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Pelican overlay", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("PELICAN STRIKE")
                .setContentText("Menu flutuante ativo").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        else Notification.Builder(this).setContentTitle("PELICAN STRIKE")
            .setContentText("Menu flutuante ativo").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(7, n)
    }

    private fun params() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun shape(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; setStroke(2, neon) }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "◎"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(neon)
            background = shape(dark, 100f)
            elevation = 12f
            setPadding(12, 7, 12, 7)
        }
        val p = params().apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18; y = 220
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=p.x; sy=p.y; tx=e.rawX; ty=e.rawY; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-tx).toInt(); val dy=(e.rawY-ty).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=max(0,sx+dx); p.y=max(0,sy+dy); wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel); panel = null
        } else showPanel()
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = shape(dark, 28f)
            elevation = 18f
        }
        val header = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text="PELICAN  /  STRIKE"; textSize=17f; typeface=Typeface.DEFAULT_BOLD
            setTextColor(neon)
        }
        val close = TextView(this).apply {
            text="  ✕"; textSize=20f; setTextColor(Color.WHITE)
            setOnClickListener { togglePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(close)
        box.addView(header)
        val subtitle = TextView(this).apply {
            text="TRAINING TOOLKIT"; textSize=10f; setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 12)
        }
        box.addView(subtitle)
        addSection(box, "AIM TRAINER", "Treino de precisão independente do jogo.")
        addSection(box, "SENSITIVITY", "Anote e compare suas configurações.")
        addSection(box, "HUD EDITOR", "Guia para organizar seus controles.")
        addSection(box, "PERFORMANCE", "Atalho para as configurações do Android.")
        val hide = TextView(this).apply {
            text="OCULTAR BOLHA"; gravity=Gravity.CENTER; textSize=12f
            setTextColor(neon); setPadding(8,14,8,4)
            setOnClickListener {
                togglePanel()
                bubble?.let { wm.removeView(it) }
                bubble = null
            }
        }
        box.addView(hide)
        val pp = params().apply { gravity=Gravity.TOP or Gravity.END; x=18; y=180 }
        panel = box
        wm.addView(box, pp)
    }

    private fun addSection(parent: LinearLayout, heading: String, detail: String) {
        val card = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(12,10,12,10)
            background=GradientDrawable().apply {
                setColor(Color.rgb(22,29,25)); cornerRadius=16f
            }
        }
        val h = TextView(this).apply { text=heading; textSize=13f; typeface=Typeface.DEFAULT_BOLD; setTextColor(neon) }
        val d = TextView(this).apply { text=detail; textSize=11f; setTextColor(Color.LTGRAY); setPadding(0,3,0,0) }
        card.addView(h); card.addView(d)
        val lp=LinearLayout.LayoutParams(270, -2); lp.bottomMargin=8
        parent.addView(card, lp)
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) }; bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel=null; bubble=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
