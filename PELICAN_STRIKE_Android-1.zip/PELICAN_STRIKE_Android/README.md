# PELICAN STRIKE — Android companion overlay

Projeto Android Studio em Kotlin, com bolha flutuante circular de mira verde-neon e painel preto.

## O que está incluído
- Atividade inicial para conceder permissão de sobreposição.
- Serviço em primeiro plano para manter a bolha flutuante.
- Bolha arrastável; toque abre/fecha o painel.
- Painel com cartões Aim Trainer, Sensitivity, HUD Editor e Performance (interface demonstrativa).

## Limites
Este projeto é um companion tool visual. Não injeta código no Blood Strike, não lê memória/tela do jogo, não oferece ESP, aimbot, disparo automático ou automação de partidas. Os cartões são atualmente informativos; não são ferramentas que modificam o jogo.

## Gerar o APK
1. Abra a pasta `PELICAN_STRIKE_Android` no Android Studio.
2. Aguarde a sincronização do Gradle e instale os componentes Android SDK solicitados (compileSdk 35).
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Testar no Android
Instale o APK, abra PELICAN STRIKE, toque em **ATIVAR MENU FLUTUANTE** e conceda a permissão “Exibir sobre outros apps”. Volte ao app e toque novamente no botão. A bolha ◎ aparece sobre outros aplicativos. Toque nela para abrir o painel; arraste para reposicionar.

## Compilação automática pelo GitHub (sem instalar Android Studio no celular)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta.
2. Abra a aba **Actions** do repositório.
3. Execute **Build PELICAN STRIKE APK** em **Run workflow** (ou aguarde o build após enviar para `main`).
4. Quando terminar, abra a execução concluída e baixe o artefato `PELICAN-STRIKE-debug-apk`.
5. Extraia o ZIP do artefato: dentro estará `app-debug.apk`.
